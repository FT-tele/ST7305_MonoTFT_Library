#ifndef ST73XX_PINS_H
#define ST73XX_PINS_H
struct ST73xxPins {
  int dc;
  int cs;
  int sclk;
  int sdin;
  int rst;
};
#endif
