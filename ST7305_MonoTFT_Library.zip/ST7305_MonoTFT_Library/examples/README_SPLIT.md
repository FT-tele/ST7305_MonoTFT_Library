# Examples split by panel size

**4.2" panel (300×400)**  
- `4p2_MultipleLanguages/`  
- `4p2_calendarAnimation/`  
- `_4p2_extras/ESP32S3-SPI_ST7305_MonoTFT4.2inch_300X400/` (PlatformIO demo for reference)

**2.9" panel (168×384)**  
- `2p9_ProductManufacturer/`

All examples include `#include <DisplayConfig.h>` and use the default-pin constructors.
