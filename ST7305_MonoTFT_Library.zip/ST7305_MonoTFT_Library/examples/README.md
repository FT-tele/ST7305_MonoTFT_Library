# ST7305 Demo Examples

Only three demos are provided and maintained:

- **2.9" (168×384)**  
  `2p9_ProductManufacturer/`

- **4.2" (300×400)**  
  `4p2_MultipleLanguages/`  
  `4p2_calendarAnimation/`

Each demo uses default pin constructors and defines its own DISPLAY_WIDTH/HEIGHT fallback macros.
