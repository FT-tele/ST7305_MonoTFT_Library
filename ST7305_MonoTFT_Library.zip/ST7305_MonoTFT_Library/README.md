# ST7305_MonoTFT_Library

Portable ST7305 mono TFT driver.

## Configure Resolution
- Edit `src/DisplayConfig.h`:

  ```c
  #define DISPLAY_WIDTH   168
  #define DISPLAY_HEIGHT  384
  ```

## Examples
- MultipleLanguages
- calendarAnimation
